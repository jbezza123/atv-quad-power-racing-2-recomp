#if defined(_WIN32)
#define COBJMACROS
#include <windows.h>
#include <d3d11.h>
#include <d3dcompiler.h>
#include <stdint.h>
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "../kernel/nv2a_backend.h"
#include "nv2a_backend_d3d11.h"

extern ptrdiff_t xbox_GetMemoryOffset(void);

/* First milestone: GPU rasterisation with a readback at flip. Textures,
 * depth/stencil and uncommon blend equations are intentionally left to the
 * CPU fallback until the solid-colour path is verified against the title. */
typedef struct {
    float x, y, z, rhw;
    float color[4];
    float u, v;
} D3DVertex;

typedef struct {
    float width, height;
    float tex_width, tex_height;
    float use_texture, combiner_mode, reserved0, reserved1;
    float alpha_test, alpha_func, alpha_ref, reserved2;
} FrameCB;

typedef struct {
    ID3D11Texture2D *texture;
    ID3D11ShaderResourceView *srv;
    uint32_t offset, width, height, pitch, color;
    uint32_t age;
} D3DTextureCacheEntry;

static ID3D11Device           *s_dev;
static ID3D11DeviceContext    *s_ctx;
static ID3D11Texture2D        *s_color;
static ID3D11RenderTargetView *s_rtv;
static ID3D11Texture2D        *s_readback;
static ID3D11Texture2D        *s_depth;
static ID3D11DepthStencilView *s_dsv;
static ID3D11Buffer           *s_vb;
static ID3D11Buffer           *s_cb;
static ID3D11VertexShader     *s_vs;
static ID3D11PixelShader     *s_ps;
static ID3D11InputLayout     *s_layout;
static ID3D11BlendState      *s_blend;
static ID3D11DepthStencilState *s_depth_disabled;
static ID3D11DepthStencilState *s_depth_dynamic;
static uint32_t s_blend_key[5];
static uint32_t s_depth_key[2];
static int s_blend_key_valid, s_depth_key_valid;
static ID3D11Texture2D       *s_tex;
static ID3D11ShaderResourceView *s_srv;
static ID3D11SamplerState     *s_sampler;
static uint32_t s_sampler_u, s_sampler_v, s_sampler_filter;
/* The frontend alternates through more than eight atlases during a menu
 * frame. Keep enough decoded resources resident to avoid upload thrashing;
 * the LRU replacement still bounds memory use. */
static D3DTextureCacheEntry s_tex_cache[32];
static uint32_t s_tex_cache_age;
static uint32_t s_width, s_height, s_pitch;
static uint32_t s_color_va;
static uint32_t s_tex_offset, s_tex_width, s_tex_height, s_tex_pitch, s_tex_color;
static uint32_t s_draw_count;
static uint32_t s_max_draws;
static uint32_t s_callback_count;
static int s_combiner_logged;
static int s_alpha_logged;
static int s_depth_logged;
static uint32_t s_depth_batches;
static uint32_t s_frame_count;
static int s_probe;
static int s_present_once;
static int s_continuous;
static int s_present_pending;
static int s_frame_limited;
static int s_active;

static D3D11_BLEND d3d_blend_factor(uint32_t f)
{
    switch (f) {
    case 0x0: return D3D11_BLEND_ZERO;
    case 0x1: return D3D11_BLEND_ONE;
    case 0x300: return D3D11_BLEND_SRC_COLOR;
    case 0x301: return D3D11_BLEND_INV_SRC_COLOR;
    case 0x302: return D3D11_BLEND_SRC_ALPHA;
    case 0x303: return D3D11_BLEND_INV_SRC_ALPHA;
    case 0x304: return D3D11_BLEND_DEST_ALPHA;
    case 0x305: return D3D11_BLEND_INV_DEST_ALPHA;
    case 0x306: return D3D11_BLEND_DEST_COLOR;
    case 0x307: return D3D11_BLEND_INV_DEST_COLOR;
    case 0x308: return D3D11_BLEND_SRC_ALPHA_SAT;
    default: return D3D11_BLEND_ONE;
    }
}

static D3D11_COMPARISON_FUNC d3d_compare_func(uint32_t f)
{
    switch (f) {
    case 0x200: return D3D11_COMPARISON_NEVER;
    case 0x201: return D3D11_COMPARISON_LESS;
    case 0x202: return D3D11_COMPARISON_EQUAL;
    case 0x203: return D3D11_COMPARISON_LESS_EQUAL;
    case 0x204: return D3D11_COMPARISON_GREATER;
    case 0x205: return D3D11_COMPARISON_NOT_EQUAL;
    case 0x206: return D3D11_COMPARISON_GREATER_EQUAL;
    case 0x207: return D3D11_COMPARISON_ALWAYS;
    default: return D3D11_COMPARISON_ALWAYS;
    }
}

static D3D11_BLEND_OP d3d_blend_op(uint32_t op)
{
    switch (op) {
    case 0x800A: return D3D11_BLEND_OP_SUBTRACT;
    case 0x800B: return D3D11_BLEND_OP_REV_SUBTRACT;
    case 0x8007: return D3D11_BLEND_OP_MIN;
    case 0x8008: return D3D11_BLEND_OP_MAX;
    default: return D3D11_BLEND_OP_ADD;
    }
}

static D3D11_TEXTURE_ADDRESS_MODE d3d_address_mode(uint32_t mode)
{
    switch (mode) {
    case 1: return D3D11_TEXTURE_ADDRESS_WRAP;
    case 2: return D3D11_TEXTURE_ADDRESS_MIRROR;
    case 3: return D3D11_TEXTURE_ADDRESS_CLAMP;
    case 4: return D3D11_TEXTURE_ADDRESS_BORDER;
    default: return D3D11_TEXTURE_ADDRESS_CLAMP;
    }
}

static float d3d_depth_value(float z)
{
    /* Fixed-function batches arrive with normalized window depth. Vertex
     * programs convert their viewport depth to the Xbox integer Z range
     * before the backend callback; ATV uses the Z24 path. */
    if (z > 1.0f)
        z /= 16777215.0f;
    if (z < 0.0f) return 0.0f;
    if (z > 1.0f) return 1.0f;
    return z;
}

static int update_sampler(const Nv2aTexture *t)
{
    D3D11_SAMPLER_DESC sampler;
    HRESULT hr;
    uint32_t u, v, mag, min;
    int linear;

    if (!t || !s_dev) return 0;
    u = t->addr_u; v = t->addr_v;
    mag = (t->filter >> 24) & 0xF;
    min = (t->filter >> 16) & 0xFF;
    linear = mag == 2 || min == 2 || min == 4 || min == 6;
    if (s_sampler && s_sampler_u == u && s_sampler_v == v &&
        s_sampler_filter == (uint32_t)linear) return 1;
    if (s_sampler) { ID3D11SamplerState_Release(s_sampler); s_sampler = NULL; }
    ZeroMemory(&sampler, sizeof(sampler));
    sampler.Filter = linear ? D3D11_FILTER_MIN_MAG_LINEAR_MIP_POINT
                             : D3D11_FILTER_MIN_MAG_MIP_POINT;
    sampler.AddressU = d3d_address_mode(u);
    sampler.AddressV = d3d_address_mode(v);
    sampler.AddressW = D3D11_TEXTURE_ADDRESS_CLAMP;
    sampler.BorderColor[0] = sampler.BorderColor[1] = sampler.BorderColor[2] = 0.0f;
    sampler.BorderColor[3] = 0.0f;
    sampler.MaxLOD = D3D11_FLOAT32_MAX;
    hr = ID3D11Device_CreateSamplerState(s_dev, &sampler, &s_sampler);
    if (FAILED(hr)) return 0;
    s_sampler_u = u; s_sampler_v = v; s_sampler_filter = (uint32_t)linear;
    fprintf(stderr, "[D3D11-BACKEND] sampler address_u=%u address_v=%u filter=%s\n",
            u, v, linear ? "linear" : "point");
    return 1;
}

static const char s_hlsl[] =
    "cbuffer Frame : register(b0) { float2 size; float2 texSize; float useTexture; float combinerMode; float2 unused; float alphaTest; float alphaFunc; float alphaRef; float unused2; };\n"
    "Texture2D tex0 : register(t0); SamplerState samp0 : register(s0);\n"
    "struct VSIn { float3 pos : POSITION; float rhw : TEXCOORD1;"
                 " float4 color : COLOR0; float2 uv : TEXCOORD0; };\n"
    "struct VSOut { float4 pos : SV_Position; float4 color : COLOR0; float2 uv : TEXCOORD0; };\n"
    "VSOut vs(VSIn i) { VSOut o; float2 p = i.pos.xy;"
    " o.pos = float4(p.x / size.x * 2.0 - 1.0,"
    " 1.0 - p.y / size.y * 2.0, 0.5, 1.0);"
    " o.color = i.color; o.uv = i.uv / texSize; return o; }\n"
    "float4 ps(VSOut i) : SV_Target {\n"
    "  float4 outColor = i.color;\n"
    "  if (useTexture > 0.5) {\n"
    "    float4 t = tex0.Sample(samp0, i.uv);\n"
    "    outColor = combinerMode > 0.5 ? saturate(float4(t.rgb * i.color.rgb * 2.0, t.a * i.color.a)) : t * i.color;\n"
    "  }\n"
    "  if (alphaTest > 0.5) {\n"
    "    int f = (int)alphaFunc; bool alphaPass = true;\n"
    "    if (f == 0x0200) alphaPass = false;\n"
    "    else if (f == 0x0201) alphaPass = outColor.a < alphaRef;\n"
    "    else if (f == 0x0202) alphaPass = abs(outColor.a - alphaRef) <= (1.0 / 255.0);\n"
    "    else if (f == 0x0203) alphaPass = outColor.a <= alphaRef;\n"
    "    else if (f == 0x0204) alphaPass = outColor.a > alphaRef;\n"
    "    else if (f == 0x0205) alphaPass = abs(outColor.a - alphaRef) > (1.0 / 255.0);\n"
    "    else if (f == 0x0206) alphaPass = outColor.a >= alphaRef;\n"
    "    if (!alphaPass) discard;\n"
    "  }\n"
    "  return outColor;\n"
    "}\n";

static void release_all(void)
{
    if (s_ctx) ID3D11DeviceContext_ClearState(s_ctx);
    if (s_blend) ID3D11BlendState_Release(s_blend);
    if (s_sampler) ID3D11SamplerState_Release(s_sampler);
    {
        uint32_t i;
        for (i = 0; i < sizeof(s_tex_cache) / sizeof(s_tex_cache[0]); i++) {
            if (s_tex_cache[i].srv) ID3D11ShaderResourceView_Release(s_tex_cache[i].srv);
            if (s_tex_cache[i].texture) ID3D11Texture2D_Release(s_tex_cache[i].texture);
            ZeroMemory(&s_tex_cache[i], sizeof(s_tex_cache[i]));
        }
    }
    if (s_depth_disabled) ID3D11DepthStencilState_Release(s_depth_disabled);
    if (s_depth_dynamic) ID3D11DepthStencilState_Release(s_depth_dynamic);
    if (s_layout) ID3D11InputLayout_Release(s_layout);
    if (s_vs) ID3D11VertexShader_Release(s_vs);
    if (s_ps) ID3D11PixelShader_Release(s_ps);
    if (s_cb) ID3D11Buffer_Release(s_cb);
    if (s_vb) ID3D11Buffer_Release(s_vb);
    if (s_dsv) ID3D11DepthStencilView_Release(s_dsv);
    if (s_depth) ID3D11Texture2D_Release(s_depth);
    if (s_readback) ID3D11Texture2D_Release(s_readback);
    if (s_rtv) ID3D11RenderTargetView_Release(s_rtv);
    if (s_color) ID3D11Texture2D_Release(s_color);
    if (s_ctx) ID3D11DeviceContext_Release(s_ctx);
    if (s_dev) ID3D11Device_Release(s_dev);
    s_blend = NULL; s_sampler = NULL; s_srv = NULL; s_tex = NULL;
    s_depth_disabled = NULL; s_depth_dynamic = NULL; s_layout = NULL;
    s_vs = NULL; s_ps = NULL; s_cb = NULL; s_vb = NULL;
    s_dsv = NULL; s_depth = NULL; s_readback = NULL;
    s_rtv = NULL; s_color = NULL; s_ctx = NULL; s_dev = NULL;
    s_width = s_height = s_pitch = s_color_va = 0;
    s_tex_offset = s_tex_width = s_tex_height = s_tex_pitch = s_tex_color = 0;
    s_tex_cache_age = 0;
    s_draw_count = s_frame_count = s_callback_count = 0;
    s_probe = s_present_once = s_continuous = s_present_pending = s_frame_limited = 0;
    s_blend_key_valid = s_depth_key_valid = 0;
    s_depth_logged = 0;
    s_depth_batches = 0;
    s_sampler_u = s_sampler_v = s_sampler_filter = 0;
}

static ID3DBlob *compile_shader(const char *entry, const char *target)
{
    ID3DBlob *code = NULL, *errors = NULL;
    HRESULT hr = D3DCompile(s_hlsl, sizeof(s_hlsl) - 1, "nv2a_backend_d3d11",
                            NULL, NULL, entry, target, 0, 0, &code, &errors);
    if (FAILED(hr)) {
        fprintf(stderr, "[D3D11-BACKEND] shader %s failed: %s\n", entry,
                errors ? (const char *)ID3D10Blob_GetBufferPointer(errors) : "unknown");
        if (errors) ID3D10Blob_Release(errors);
        return NULL;
    }
    if (errors) ID3D10Blob_Release(errors);
    return code;
}

static int create_target(uint32_t width, uint32_t height)
{
    D3D11_TEXTURE2D_DESC td;
    D3D11_RENDER_TARGET_VIEW_DESC rv;
    D3D11_DEPTH_STENCIL_VIEW_DESC dv;
    D3D11_DEPTH_STENCIL_DESC ds;
    D3D11_BUFFER_DESC bd;
    D3D11_SUBRESOURCE_DATA init;
    D3D11_SAMPLER_DESC sampler;
    HRESULT hr;

    if (!s_dev || !width || !height || width > 4096 || height > 4096)
        return 0;
    if (s_width == width && s_height == height && s_rtv)
        return 1;

    if (s_ctx) ID3D11DeviceContext_OMSetRenderTargets(s_ctx, 0, NULL, NULL);
    if (s_rtv) { ID3D11RenderTargetView_Release(s_rtv); s_rtv = NULL; }
    if (s_color) { ID3D11Texture2D_Release(s_color); s_color = NULL; }
    if (s_readback) { ID3D11Texture2D_Release(s_readback); s_readback = NULL; }
    if (s_dsv) { ID3D11DepthStencilView_Release(s_dsv); s_dsv = NULL; }
    if (s_depth) { ID3D11Texture2D_Release(s_depth); s_depth = NULL; }

    ZeroMemory(&td, sizeof(td));
    td.Width = width; td.Height = height; td.MipLevels = 1; td.ArraySize = 1;
    td.Format = DXGI_FORMAT_B8G8R8A8_UNORM; td.SampleDesc.Count = 1;
    td.Usage = D3D11_USAGE_DEFAULT; td.BindFlags = D3D11_BIND_RENDER_TARGET;
    hr = ID3D11Device_CreateTexture2D(s_dev, &td, NULL, &s_color);
    if (FAILED(hr)) return 0;
    ZeroMemory(&rv, sizeof(rv)); rv.Format = td.Format; rv.ViewDimension = D3D11_RTV_DIMENSION_TEXTURE2D;
    hr = ID3D11Device_CreateRenderTargetView(s_dev, (ID3D11Resource *)s_color, &rv, &s_rtv);
    if (FAILED(hr)) return 0;

    td.Format = DXGI_FORMAT_D24_UNORM_S8_UINT;
    td.BindFlags = D3D11_BIND_DEPTH_STENCIL;
    hr = ID3D11Device_CreateTexture2D(s_dev, &td, NULL, &s_depth);
    if (FAILED(hr)) return 0;
    ZeroMemory(&dv, sizeof(dv)); dv.Format = td.Format; dv.ViewDimension = D3D11_DSV_DIMENSION_TEXTURE2D;
    hr = ID3D11Device_CreateDepthStencilView(s_dev, (ID3D11Resource *)s_depth, &dv, &s_dsv);
    if (FAILED(hr)) return 0;

    td.Format = DXGI_FORMAT_B8G8R8A8_UNORM;
    td.Usage = D3D11_USAGE_STAGING; td.BindFlags = 0;
    td.CPUAccessFlags = D3D11_CPU_ACCESS_READ;
    hr = ID3D11Device_CreateTexture2D(s_dev, &td, NULL, &s_readback);
    if (FAILED(hr)) return 0;

    ZeroMemory(&ds, sizeof(ds));
    ds.DepthEnable = FALSE; ds.DepthWriteMask = D3D11_DEPTH_WRITE_MASK_ZERO;
    ds.DepthFunc = D3D11_COMPARISON_ALWAYS;
    hr = ID3D11Device_CreateDepthStencilState(s_dev, &ds, &s_depth_disabled);
    if (FAILED(hr)) return 0;

    ZeroMemory(&bd, sizeof(bd));
    bd.Usage = D3D11_USAGE_DYNAMIC; bd.ByteWidth = sizeof(D3DVertex) * 65536;
    bd.BindFlags = D3D11_BIND_VERTEX_BUFFER; bd.CPUAccessFlags = D3D11_CPU_ACCESS_WRITE;
    hr = ID3D11Device_CreateBuffer(s_dev, &bd, NULL, &s_vb);
    if (FAILED(hr)) return 0;

    ZeroMemory(&bd, sizeof(bd));
    bd.Usage = D3D11_USAGE_DEFAULT; bd.ByteWidth = sizeof(FrameCB);
    bd.BindFlags = D3D11_BIND_CONSTANT_BUFFER;
    ZeroMemory(&init, sizeof(init));
    {
        FrameCB cb = { (float)width, (float)height };
        init.pSysMem = &cb;
        hr = ID3D11Device_CreateBuffer(s_dev, &bd, &init, &s_cb);
    }
    if (FAILED(hr)) return 0;

    if (!s_sampler) {
        ZeroMemory(&sampler, sizeof(sampler));
        sampler.Filter = D3D11_FILTER_MIN_MAG_MIP_LINEAR;
        sampler.AddressU = D3D11_TEXTURE_ADDRESS_CLAMP;
        sampler.AddressV = D3D11_TEXTURE_ADDRESS_CLAMP;
        sampler.AddressW = D3D11_TEXTURE_ADDRESS_CLAMP;
        sampler.MaxLOD = D3D11_FLOAT32_MAX;
        hr = ID3D11Device_CreateSamplerState(s_dev, &sampler, &s_sampler);
        if (FAILED(hr)) return 0;
    }

    s_width = width; s_height = height;
    return 1;
}

static int upload_texture(const Nv2aTexture *t)
{
    D3D11_TEXTURE2D_DESC td;
    D3D11_SHADER_RESOURCE_VIEW_DESC sd;
    D3D11_SUBRESOURCE_DATA init;
    ID3D11Texture2D *tex = NULL;
    ID3D11ShaderResourceView *srv = NULL;
    uint32_t *pixels;
    uint32_t i, slot = 0, mip_levels;
    int generate_mips;
    size_t count;
    HRESULT hr;

    if (!t || !t->width || !t->height || t->width > 2048 || t->height > 2048)
        return 0;
    for (i = 0; i < sizeof(s_tex_cache) / sizeof(s_tex_cache[0]); i++) {
        D3DTextureCacheEntry *entry = &s_tex_cache[i];
        if (entry->texture && entry->offset == t->offset && entry->width == t->width &&
            entry->height == t->height && entry->pitch == t->pitch && entry->color == t->color) {
            entry->age = ++s_tex_cache_age;
            s_tex = entry->texture; s_srv = entry->srv;
            s_tex_offset = t->offset; s_tex_width = t->width;
            s_tex_height = t->height; s_tex_pitch = t->pitch; s_tex_color = t->color;
            return update_sampler(t);
        }
    }
    count = (size_t)t->width * t->height;
    if (count > 2048u * 2048u) return 0;
    pixels = (uint32_t *)malloc(count * sizeof(*pixels));
    if (!pixels) return 0;
    if (!nv2a_backend_decode_texture(t, pixels)) {
        free(pixels);
        return 0;
    }
    ZeroMemory(&td, sizeof(td));
    generate_mips = t->levels > 1;
    mip_levels = generate_mips ? t->levels : 1;
    if (mip_levels > 12) mip_levels = 12;
    td.Width = t->width; td.Height = t->height; td.MipLevels = mip_levels; td.ArraySize = 1;
    td.Format = DXGI_FORMAT_B8G8R8A8_UNORM; td.SampleDesc.Count = 1;
    td.Usage = generate_mips ? D3D11_USAGE_DEFAULT : D3D11_USAGE_IMMUTABLE;
    td.BindFlags = D3D11_BIND_SHADER_RESOURCE |
                   (generate_mips ? D3D11_BIND_RENDER_TARGET : 0);
    td.MiscFlags = generate_mips ? D3D11_RESOURCE_MISC_GENERATE_MIPS : 0;
    ZeroMemory(&init, sizeof(init));
    init.pSysMem = pixels; init.SysMemPitch = t->width * sizeof(uint32_t);
    hr = ID3D11Device_CreateTexture2D(s_dev, &td, generate_mips ? NULL : &init, &tex);
    if (SUCCEEDED(hr) && generate_mips)
        ID3D11DeviceContext_UpdateSubresource(s_ctx, (ID3D11Resource *)tex, 0,
                                              NULL, pixels, t->width * sizeof(uint32_t), 0);
    free(pixels);
    if (FAILED(hr)) return 0;
    ZeroMemory(&sd, sizeof(sd));
    sd.Format = td.Format; sd.ViewDimension = D3D11_SRV_DIMENSION_TEXTURE2D;
    sd.Texture2D.MipLevels = mip_levels;
    hr = ID3D11Device_CreateShaderResourceView(s_dev, (ID3D11Resource *)tex, &sd, &srv);
    if (FAILED(hr)) {
        ID3D11Texture2D_Release(tex);
        return 0;
    }
    if (generate_mips)
        ID3D11DeviceContext_GenerateMips(s_ctx, srv);
    for (i = 1; i < sizeof(s_tex_cache) / sizeof(s_tex_cache[0]); i++) {
        if (!s_tex_cache[i].texture) { slot = i; break; }
        if (!s_tex_cache[i].age || s_tex_cache[i].age < s_tex_cache[slot].age) slot = i;
    }
    if (s_tex_cache[slot].srv) ID3D11ShaderResourceView_Release(s_tex_cache[slot].srv);
    if (s_tex_cache[slot].texture) ID3D11Texture2D_Release(s_tex_cache[slot].texture);
    s_tex_cache[slot].texture = tex; s_tex_cache[slot].srv = srv;
    s_tex_cache[slot].offset = t->offset; s_tex_cache[slot].width = t->width;
    s_tex_cache[slot].height = t->height; s_tex_cache[slot].pitch = t->pitch;
    s_tex_cache[slot].color = t->color; s_tex_cache[slot].age = ++s_tex_cache_age;
    s_tex = tex; s_srv = srv;
    s_tex_offset = t->offset; s_tex_width = t->width; s_tex_pitch = t->pitch;
    s_tex_height = t->height; s_tex_color = t->color;
    fprintf(stderr, "[D3D11-BACKEND] cached texture slot=%u %ux%u fmt=0x%02X\n",
            slot, t->width, t->height, t->color & 0xFF);
    if (generate_mips)
        fprintf(stderr, "[D3D11-BACKEND] generated mip chain levels=%u\n", mip_levels);
    return update_sampler(t);
}

static void apply_render_state(const Nv2aRenderState *rs)
{
    D3D11_BLEND_DESC blend;
    D3D11_DEPTH_STENCIL_DESC depth;
    UINT mask = D3D11_COLOR_WRITE_ENABLE_ALL;
    uint32_t bkey[5], dkey[2];
    HRESULT hr;

    if (!rs) {
        ID3D11DeviceContext_OMSetBlendState(s_ctx, NULL, NULL, 0xFFFFFFFF);
        ID3D11DeviceContext_OMSetDepthStencilState(s_ctx, s_depth_disabled, 0);
        return;
    }
    if (rs->color_mask) {
        mask = 0;
        if (rs->color_mask & 0x00000001) mask |= D3D11_COLOR_WRITE_ENABLE_BLUE;
        if (rs->color_mask & 0x00000100) mask |= D3D11_COLOR_WRITE_ENABLE_GREEN;
        if (rs->color_mask & 0x00010000) mask |= D3D11_COLOR_WRITE_ENABLE_RED;
        if (rs->color_mask & 0x01000000) mask |= D3D11_COLOR_WRITE_ENABLE_ALPHA;
    }
    bkey[0] = rs->blend_enable; bkey[1] = rs->blend_src;
    bkey[2] = rs->blend_dst; bkey[3] = rs->blend_eq; bkey[4] = mask;
    if (!s_blend_key_valid || memcmp(s_blend_key, bkey, sizeof(bkey)) != 0) {
        if (s_blend) { ID3D11BlendState_Release(s_blend); s_blend = NULL; }
        ZeroMemory(&blend, sizeof(blend));
        blend.RenderTarget[0].BlendEnable = rs->blend_enable ? TRUE : FALSE;
        blend.RenderTarget[0].SrcBlend = d3d_blend_factor(rs->blend_src);
        blend.RenderTarget[0].DestBlend = d3d_blend_factor(rs->blend_dst);
        blend.RenderTarget[0].BlendOp = d3d_blend_op(rs->blend_eq);
        blend.RenderTarget[0].SrcBlendAlpha = blend.RenderTarget[0].SrcBlend;
        blend.RenderTarget[0].DestBlendAlpha = blend.RenderTarget[0].DestBlend;
        blend.RenderTarget[0].BlendOpAlpha = blend.RenderTarget[0].BlendOp;
        blend.RenderTarget[0].RenderTargetWriteMask = (UINT8)mask;
        hr = ID3D11Device_CreateBlendState(s_dev, &blend, &s_blend);
        s_blend_key_valid = SUCCEEDED(hr);
        if (s_blend_key_valid) memcpy(s_blend_key, bkey, sizeof(bkey));
    }
    ID3D11DeviceContext_OMSetBlendState(s_ctx, s_blend, NULL, 0xFFFFFFFF);

    if (!rs->depth_test_enable) {
        ID3D11DeviceContext_OMSetDepthStencilState(s_ctx, s_depth_disabled, 0);
        return;
    }
    dkey[0] = rs->depth_func; dkey[1] = rs->depth_write;
    if (!s_depth_key_valid || memcmp(s_depth_key, dkey, sizeof(dkey)) != 0) {
        if (s_depth_dynamic) { ID3D11DepthStencilState_Release(s_depth_dynamic); s_depth_dynamic = NULL; }
        ZeroMemory(&depth, sizeof(depth));
        depth.DepthEnable = TRUE;
        depth.DepthWriteMask = rs->depth_write ? D3D11_DEPTH_WRITE_MASK_ALL : D3D11_DEPTH_WRITE_MASK_ZERO;
        depth.DepthFunc = d3d_compare_func(rs->depth_func);
        hr = ID3D11Device_CreateDepthStencilState(s_dev, &depth, &s_depth_dynamic);
        s_depth_key_valid = SUCCEEDED(hr);
        if (s_depth_key_valid) memcpy(s_depth_key, dkey, sizeof(dkey));
    }
    ID3D11DeviceContext_OMSetDepthStencilState(s_ctx,
        s_depth_dynamic ? s_depth_dynamic : s_depth_disabled, 0);
}

static void d3d11_clear(const Nv2aSurface *surface, const Nv2aRenderState *state,
                        uint32_t flags, uint32_t argb, uint32_t zstencil)
{
    float c[4];
    (void)state; (void)zstencil;
    s_color_va = surface->color_va;
    s_pitch = surface->pitch;
    if (!create_target(surface->width, surface->height)) return;
    c[0] = ((argb >> 16) & 255) / 255.0f;
    c[1] = ((argb >> 8) & 255) / 255.0f;
    c[2] = (argb & 255) / 255.0f;
    c[3] = ((argb >> 24) & 255) / 255.0f;
    if (flags & 0xF0) ID3D11DeviceContext_ClearRenderTargetView(s_ctx, s_rtv, c);
    if ((flags & 3) && s_dsv)
        ID3D11DeviceContext_ClearDepthStencilView(s_ctx, s_dsv,
            (flags & 1 ? D3D11_CLEAR_DEPTH : 0) | (flags & 2 ? D3D11_CLEAR_STENCIL : 0), 1.0f, 0);
}

static void d3d11_draw(const Nv2aSurface *surface, const Nv2aBatch *batch)
{
    D3D11_MAPPED_SUBRESOURCE map;
    D3D11_VIEWPORT vp;
    UINT stride = sizeof(D3DVertex), offset = 0;
    FrameCB cb;
    ID3D11ShaderResourceView *srv;
    ID3D11SamplerState *sampler;
    int textured;
    uint32_t i;
    (void)surface;
    s_color_va = surface->color_va;
    s_pitch = surface->pitch;
    if (!s_active) return;
    s_callback_count++;
    if (s_callback_count <= 3) {
        fprintf(stderr, "[D3D11-BACKEND] callback %u: surface=%ux%u pitch=%u bpp=%u verts=%u tex=%s\n",
                s_callback_count, surface->width, surface->height, surface->pitch,
                surface->bytes_per_pixel, batch ? batch->count : 0,
                batch && batch->texture ? "yes" : "no");
    }
    if (!batch || !batch->vertices || batch->count < 3) return;
    if (!create_target(surface->width, surface->height)) {
        if (s_callback_count <= 3)
            fprintf(stderr, "[D3D11-BACKEND] target creation failed for %ux%u\n",
                    surface->width, surface->height);
        return;
    }
    if (s_max_draws && s_draw_count >= s_max_draws) {
        if (s_continuous) {
            if (!s_frame_limited) {
                fprintf(stderr, "[D3D11-BACKEND] frame %u draw budget %u reached; skipping remainder\n",
                        s_frame_count + 1, s_max_draws);
                s_frame_limited = 1;
            }
        } else {
            fprintf(stderr, "[D3D11-BACKEND] draw limit %u reached; disabling backend\n", s_max_draws);
            nv2a_backend_register(NULL);
            s_active = 0;
        }
        return;
    }
    if ((batch->count % 3) != 0 || batch->count > 65536) return;
    textured = batch->texture && upload_texture(batch->texture);
    cb.width = (float)s_width; cb.height = (float)s_height;
    cb.tex_width = textured ? (float)s_tex_width : 1.0f;
    cb.tex_height = textured ? (float)s_tex_height : 1.0f;
    cb.use_texture = textured ? 1.0f : 0.0f;
    cb.combiner_mode = textured && batch->combiner &&
        nv2a_rc_is_atv_texture_diffuse(batch->combiner) ? 1.0f : 0.0f;
    if (!s_combiner_logged && textured) {
        fprintf(stderr, "[D3D11-BACKEND] combiner_mode=%s\n",
                cb.combiner_mode > 0.5f ? "atv_texture_diffuse" : "fallback_texture_diffuse");
        s_combiner_logged = 1;
    }
    cb.reserved0 = cb.reserved1 = 0.0f;
    cb.alpha_test = batch->state && batch->state->alpha_test_enable ? 1.0f : 0.0f;
    cb.alpha_func = batch->state ? (float)batch->state->alpha_func : 0x0207;
    cb.alpha_ref = batch->state ? (float)(batch->state->alpha_ref & 0xFF) / 255.0f : 0.0f;
    cb.reserved2 = 0.0f;
    if (!s_alpha_logged && batch->state && batch->state->alpha_test_enable) {
        fprintf(stderr, "[D3D11-BACKEND] alpha_test=enabled func=0x%04X ref=%u\n",
                batch->state->alpha_func, batch->state->alpha_ref & 0xFF);
        s_alpha_logged = 1;
    }
    srv = textured ? s_srv : NULL;
    sampler = textured ? s_sampler : NULL;
    ID3D11DeviceContext_UpdateSubresource(s_ctx, (ID3D11Resource *)s_cb, 0,
                                          NULL, &cb, 0, 0);
    if (FAILED(ID3D11DeviceContext_Map(s_ctx, (ID3D11Resource *)s_vb, 0,
                                       D3D11_MAP_WRITE_DISCARD, 0, &map))) return;
    for (i = 0; i < batch->count; i++) {
        const Nv2aVertex *v = &batch->vertices[i];
        D3DVertex *o = &((D3DVertex *)map.pData)[i];
        o->x = v->x; o->y = v->y; o->z = d3d_depth_value(v->z); o->rhw = v->rhw;
        o->color[0] = ((v->diffuse >> 16) & 255) / 255.0f;
        o->color[1] = ((v->diffuse >> 8) & 255) / 255.0f;
        o->color[2] = (v->diffuse & 255) / 255.0f;
        o->color[3] = ((v->diffuse >> 24) & 255) / 255.0f;
        o->u = v->u; o->v = v->v;
    }
    if (batch->state && batch->state->depth_test_enable) {
        float zmin = 1.0f, zmax = 0.0f, raw_min = batch->vertices[0].z;
        float raw_max = raw_min, rhw_min = batch->vertices[0].rhw;
        float rhw_max = rhw_min;
        uint32_t j;
        for (j = 0; j < batch->count; j++) {
            float z = d3d_depth_value(batch->vertices[j].z);
            if (z < zmin) zmin = z;
            if (z > zmax) zmax = z;
            if (batch->vertices[j].z < raw_min) raw_min = batch->vertices[j].z;
            if (batch->vertices[j].z > raw_max) raw_max = batch->vertices[j].z;
            if (batch->vertices[j].rhw < rhw_min) rhw_min = batch->vertices[j].rhw;
            if (batch->vertices[j].rhw > rhw_max) rhw_max = batch->vertices[j].rhw;
        }
        s_depth_batches++;
        if (!s_depth_logged || s_depth_batches <= 8 || (s_depth_batches % 100) == 0) {
            fprintf(stderr, "[D3D11-BACKEND] depth batch=%u raw=%.6f..%.6f norm=%.6f..%.6f rhw=%.6f..%.6f\n",
                    s_depth_batches, raw_min, raw_max, zmin, zmax, rhw_min, rhw_max);
            fprintf(stderr, "[D3D11-BACKEND] depth samples z0=%.6f z1=%.6f\n",
                    d3d_depth_value(batch->vertices[0].z),
                    batch->count > 1 ? d3d_depth_value(batch->vertices[1].z) : 0.0f);
            s_depth_logged = 1;
        }
    }
    ID3D11DeviceContext_Unmap(s_ctx, (ID3D11Resource *)s_vb, 0);
    vp.TopLeftX = 0; vp.TopLeftY = 0; vp.Width = (float)s_width; vp.Height = (float)s_height;
    vp.MinDepth = 0; vp.MaxDepth = 1;
    ID3D11DeviceContext_RSSetViewports(s_ctx, 1, &vp);
    ID3D11DeviceContext_OMSetRenderTargets(s_ctx, 1, &s_rtv, s_dsv);
    apply_render_state(batch->state);
    ID3D11DeviceContext_IASetVertexBuffers(s_ctx, 0, 1, &s_vb, &stride, &offset);
    ID3D11DeviceContext_IASetInputLayout(s_ctx, s_layout);
    ID3D11DeviceContext_IASetPrimitiveTopology(s_ctx, D3D11_PRIMITIVE_TOPOLOGY_TRIANGLELIST);
    ID3D11DeviceContext_VSSetShader(s_ctx, s_vs, NULL, 0);
    ID3D11DeviceContext_VSSetConstantBuffers(s_ctx, 0, 1, &s_cb);
    ID3D11DeviceContext_PSSetShader(s_ctx, s_ps, NULL, 0);
    ID3D11DeviceContext_PSSetShaderResources(s_ctx, 0, 1, &srv);
    ID3D11DeviceContext_PSSetSamplers(s_ctx, 0, 1, &sampler);
    ID3D11DeviceContext_Draw(s_ctx, batch->count, 0);
    s_draw_count++;
    if (s_probe && s_draw_count >= s_max_draws) {
        fprintf(stderr, "[D3D11-BACKEND] probe draw %u submitted; disabling backend\n",
                s_draw_count);
        nv2a_backend_register(NULL);
        s_active = 0;
    } else if (s_present_once && s_draw_count >= s_max_draws && !s_present_pending) {
        s_present_pending = 1;
        fprintf(stderr, "[D3D11-BACKEND] present test draw %u complete; waiting for one flip\n",
                s_draw_count);
    } else if (s_continuous && s_draw_count >= s_max_draws && !s_frame_limited) {
        s_frame_limited = 1;
        fprintf(stderr, "[D3D11-BACKEND] frame %u draw budget %u reached; next flip will present\n",
                s_frame_count + 1, s_max_draws);
    }
}

static void d3d11_flip(void)
{
    D3D11_MAPPED_SUBRESOURCE map;
    uint8_t *guest;
    uint32_t y;
    if (!s_active || s_probe || (s_present_once && !s_present_pending) ||
        !s_color || !s_readback || !s_color_va) return;
    ID3D11DeviceContext_CopyResource(s_ctx, (ID3D11Resource *)s_readback,
                                     (ID3D11Resource *)s_color);
    if (FAILED(ID3D11DeviceContext_Map(s_ctx, (ID3D11Resource *)s_readback, 0,
                                       D3D11_MAP_READ, 0, &map))) {
        fprintf(stderr, "[D3D11-BACKEND] one-shot readback map failed; disabling backend\n");
        nv2a_backend_register(NULL);
        s_active = 0;
        return;
    }
    guest = (uint8_t *)xbox_GetMemoryOffset() + s_color_va;
    for (y = 0; y < s_height; y++)
        memcpy(guest + (size_t)y * s_pitch,
               (const uint8_t *)map.pData + (size_t)y * map.RowPitch,
               (size_t)s_width * 4);
    ID3D11DeviceContext_Unmap(s_ctx, (ID3D11Resource *)s_readback, 0);
    if (s_present_once) {
        fprintf(stderr, "[D3D11-BACKEND] one-shot readback copied; disabling backend\n");
        nv2a_backend_register(NULL);
        s_active = 0;
        s_present_pending = 0;
    } else if (s_continuous) {
        s_frame_count++;
        s_draw_count = 0;
        s_frame_limited = 0;
        if (s_frame_count <= 3)
            fprintf(stderr, "[D3D11-BACKEND] continuous frame %u readback copied\n", s_frame_count);
    }
}

static const Nv2aBackend s_backend = { d3d11_clear, d3d11_draw, d3d11_flip };

int nv2a_backend_d3d11_init(void)
{
    D3D_FEATURE_LEVEL level;
    D3D11_INPUT_ELEMENT_DESC input[] = {
        {"POSITION", 0, DXGI_FORMAT_R32G32B32_FLOAT, 0, 0,  D3D11_INPUT_PER_VERTEX_DATA, 0},
        {"TEXCOORD", 1, DXGI_FORMAT_R32_FLOAT,       0, 12, D3D11_INPUT_PER_VERTEX_DATA, 0},
        {"COLOR",    0, DXGI_FORMAT_R32G32B32A32_FLOAT, 0, 16, D3D11_INPUT_PER_VERTEX_DATA, 0},
        {"TEXCOORD", 0, DXGI_FORMAT_R32G32_FLOAT,    0, 32, D3D11_INPUT_PER_VERTEX_DATA, 0}
    };
    ID3DBlob *vsb, *psb;
    HRESULT hr;
    const char *e = getenv("RECOMP_D3D_BACKEND");
    const char *limit = getenv("RECOMP_D3D_MAX_DRAWS");
    if (!e || !*e || (strcmp(e, "1") != 0 && strcmp(e, "probe") != 0 &&
                      strcmp(e, "present") != 0 && strcmp(e, "continuous") != 0)) return 0;
    s_probe = strcmp(e, "probe") == 0;
    s_present_once = strcmp(e, "present") == 0;
    s_continuous = strcmp(e, "continuous") == 0;
    s_max_draws = limit && *limit ? (uint32_t)strtoul(limit, NULL, 10) :
                  (s_probe ? 1u : (s_continuous ? 100u : 1000u));
    if ((s_probe || s_present_once) && s_max_draws == 0) s_max_draws = 1;
    hr = D3D11CreateDevice(NULL, D3D_DRIVER_TYPE_HARDWARE, NULL, 0, NULL, 0,
                           D3D11_SDK_VERSION, &s_dev, &level, &s_ctx);
    if (FAILED(hr)) {
        fprintf(stderr, "[D3D11-BACKEND] device creation failed 0x%08lX; CPU renderer remains active\n", (unsigned long)hr);
        return 0;
    }
    vsb = compile_shader("vs", "vs_4_0");
    psb = compile_shader("ps", "ps_4_0");
    if (!vsb || !psb) { release_all(); return 0; }
    hr = ID3D11Device_CreateVertexShader(s_dev, ID3D10Blob_GetBufferPointer(vsb),
                                         ID3D10Blob_GetBufferSize(vsb), NULL, &s_vs);
    if (SUCCEEDED(hr)) hr = ID3D11Device_CreatePixelShader(s_dev, ID3D10Blob_GetBufferPointer(psb),
                                                            ID3D10Blob_GetBufferSize(psb), NULL, &s_ps);
    if (SUCCEEDED(hr)) hr = ID3D11Device_CreateInputLayout(s_dev, input, 4,
                                                            ID3D10Blob_GetBufferPointer(vsb),
                                                            ID3D10Blob_GetBufferSize(vsb), &s_layout);
    ID3D10Blob_Release(vsb); ID3D10Blob_Release(psb);
    if (FAILED(hr)) { release_all(); return 0; }
    s_active = 1;
    s_present_pending = 0;
    s_frame_count = s_draw_count = s_callback_count = 0;
    s_frame_limited = 0;
    nv2a_backend_register(&s_backend);
    fprintf(stderr, "[D3D11-BACKEND] initialized mode=%s max_draws=%u\n",
            s_probe ? "probe" : (s_present_once ? "present" :
             (s_continuous ? "continuous" : "full")), s_max_draws);
    return 1;
}

void nv2a_backend_d3d11_shutdown(void)
{
    if (s_active) nv2a_backend_register(NULL);
    s_active = 0;
    release_all();
    if (s_dev) fprintf(stderr, "[D3D11-BACKEND] shut down\n");
}

int nv2a_backend_d3d11_active(void) { return s_active; }

#else
#include "nv2a_backend_d3d11.h"
int nv2a_backend_d3d11_init(void) { return 0; }
void nv2a_backend_d3d11_shutdown(void) {}
int nv2a_backend_d3d11_active(void) { return 0; }
#endif
